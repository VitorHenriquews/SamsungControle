package com.example.samsungremote;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.wifi.WifiManager;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;
import org.json.JSONObject;
import okhttp3.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.io.ByteArrayOutputStream;
import java.util.*;
import java.util.concurrent.*;
import javax.net.ssl.*;
import java.security.cert.X509Certificate;

public class MainActivity extends Activity {
  private LinearLayout root, found;
  private TextView status;
  private EditText ipInput;
  private final ExecutorService executor = Executors.newSingleThreadExecutor();
  private final Set<String> discovered = new HashSet<>();
  private WebSocket socket;
  private OkHttpClient client;
  private String currentIp="";
  private boolean connected=false;
  private int connectionAttempt=0;
  private final int navy=Color.rgb(14,24,39), teal=Color.rgb(16,127,123);
  @Override public void onCreate(Bundle b) {super.onCreate(b); build();}
  private void build(){
    ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(navy);
    root=new LinearLayout(this); root.setOrientation(1); root.setPadding(24,35,24,35); scroll.addView(root); setContentView(scroll);
    TextView heading=label("CONTROLE SAMSUNG",26,true); heading.setGravity(Gravity.CENTER); root.addView(heading);
    TextView sub=label("Wi-Fi • TV Samsung TU7020",14,false); sub.setGravity(Gravity.CENTER); root.addView(sub);
    status=label("Desconectado",15,true); status.setPadding(0,22,0,14); root.addView(status);
    addButton(root,"PROCURAR TVs NA REDE",()->search());
    found=new LinearLayout(this); found.setOrientation(1); root.addView(found);
    ipInput=new EditText(this); ipInput.setSingleLine(true); ipInput.setTextColor(Color.WHITE); ipInput.setHintTextColor(0xffb0bfc9); ipInput.setHint("IP da TV (alternativa)"); ipInput.setInputType(InputType.TYPE_CLASS_PHONE); root.addView(ipInput);
    String saved=getPreferences(0).getString("ip",""); ipInput.setText(saved);
    addButton(root,"CONECTAR PELO IP",()->connect(ipInput.getText().toString().trim()));
    addButton(root,"DESCONECTAR",()->{connectionAttempt++; if(socket!=null)socket.close(1000,"Fechado"); connected=false; setStatus("Desconectado");});
    addRemote();
    TextView foot=label("Celular e TV precisam estar no mesmo Wi-Fi. Autorize o acesso na tela da TV. A busca e os comandos dependem do modelo e da configuração de rede.",12,false); foot.setPadding(0,25,0,0); root.addView(foot);
  }
  private TextView label(String s,int sp,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(Color.WHITE);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
  private void addButton(LinearLayout parent,String text,Runnable action){Button b=new Button(this);b.setText(text);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(teal));parent.addView(b,new LinearLayout.LayoutParams(-1,-2));b.setOnClickListener(v->action.run());}
  private void addRemote(){
    addRow(new String[]{"⏻","MUDO","HOME"},new String[]{"KEY_POWER","KEY_MUTE","KEY_HOME"});
    addRow(new String[]{"VOL +","↑","CH +"},new String[]{"KEY_VOLUP","KEY_UP","KEY_CHUP"});
    addRow(new String[]{"←","OK","→"},new String[]{"KEY_LEFT","KEY_ENTER","KEY_RIGHT"});
    addRow(new String[]{"VOL −","↓","CH −"},new String[]{"KEY_VOLDOWN","KEY_DOWN","KEY_CHDOWN"});
    addRow(new String[]{"VOLTAR","SOURCE","MENU"},new String[]{"KEY_RETURN","KEY_SOURCE","KEY_MENU"});
  }
  private void addRow(String[] names,String[] keys){LinearLayout r=new LinearLayout(this);r.setOrientation(0);root.addView(r);for(int i=0;i<3;i++){final String key=keys[i];Button b=new Button(this);b.setText(names[i]);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff263e54));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,65,1);p.setMargins(2,3,2,3);r.addView(b,p);b.setOnClickListener(v->send(key));}}
  private void setStatus(String s){runOnUiThread(()->status.setText(s));}
  private void search(){
    found.removeAllViews();discovered.clear();setStatus("Procurando TVs por SSDP... (até 7 segundos)");
    executor.execute(()->{
      WifiManager.MulticastLock lock=null;
      try{
        WifiManager wifi=(WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        lock=wifi.createMulticastLock("samsung-search");lock.setReferenceCounted(false);lock.acquire();
        DatagramSocket ds=new DatagramSocket();ds.setSoTimeout(750);
        String[] targets={"ssdp:all","urn:schemas-upnp-org:device:MediaRenderer:1"};
        for(String target:targets){String msg="M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: "+target+"\r\n\r\n";byte[] bytes=msg.getBytes(StandardCharsets.UTF_8);ds.send(new DatagramPacket(bytes,bytes.length,InetAddress.getByName("239.255.255.250"),1900));}
        long until=System.currentTimeMillis()+7000;
        while(System.currentTimeMillis()<until){try{byte[] buf=new byte[8192];DatagramPacket packet=new DatagramPacket(buf,buf.length);ds.receive(packet);String body=new String(packet.getData(),0,packet.getLength(),StandardCharsets.UTF_8).toLowerCase(Locale.ROOT);String ip=packet.getAddress().getHostAddress();if(body.contains("samsung") || body.contains("mediarenderer")){if(discovered.add(ip))runOnUiThread(()->addFound(ip));}}catch(SocketTimeoutException ignored){}}
        ds.close();
        if(discovered.isEmpty())setStatus("Nenhuma TV encontrada. Confira o Wi-Fi ou use o IP.");else setStatus("TVs/dispositivos encontrados: "+discovered.size()+". Toque para conectar.");
      }catch(Exception e){setStatus("Falha na busca: "+e.getMessage());}finally{if(lock!=null&&lock.isHeld())lock.release();}
    });
  }
  private void addFound(String ip){addButton(found,"TV/dispositivo encontrado: "+ip+"  •  CONECTAR",()->{ipInput.setText(ip);connect(ip);});}
  private void connect(String ip){
    if(!ip.matches("(?:\\d{1,3}\\.){3}\\d{1,3}")){setStatus("Digite um IPv4 válido da TV.");return;}
    String[] nums=ip.split("\\.");for(String n:nums)if(Integer.parseInt(n)>255){setStatus("IP inválido.");return;}
    currentIp=ip;connected=false;int attempt=++connectionAttempt;
    getPreferences(0).edit().putString("ip",ip).apply();setStatus("Conectando à TV "+ip+"...");
    if(socket!=null)socket.cancel();
    try{
      // TVs Samsung podem usar certificado autoassinado na porta LAN 8002.
      // A exceção TLS abaixo aplica-se APENAS à conexão com o IP local informado.
      X509TrustManager trust=new X509TrustManager(){public void checkClientTrusted(X509Certificate[] c,String a){}public void checkServerTrusted(X509Certificate[] c,String a){}public X509Certificate[] getAcceptedIssuers(){return new X509Certificate[0];}};
      SSLContext tls=SSLContext.getInstance("TLS");tls.init(null,new TrustManager[]{trust},new java.security.SecureRandom());
      client=new OkHttpClient.Builder().sslSocketFactory(tls.getSocketFactory(),trust).hostnameVerifier((host,session)->host.equals(ip)).connectTimeout(6,TimeUnit.SECONDS).readTimeout(0,TimeUnit.MILLISECONDS).build();
      String name=android.util.Base64.encodeToString("Controle Samsung".getBytes(StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);
      String url="wss://"+ip+":8002/api/v2/channels/samsung.remote.control?name="+name;
      Request req=new Request.Builder().url(url).build();
      socket=client.newWebSocket(req,new WebSocketListener(){
        @Override public void onOpen(WebSocket ws,okhttp3.Response resp){if(attempt!=connectionAttempt){ws.close(1000,"stale");return;}setStatus("Conexão aberta. Autorize na TV, se solicitado...");}
        @Override public void onMessage(WebSocket ws,String message){if(attempt!=connectionAttempt)return;try{JSONObject j=new JSONObject(message);String event=j.optString("event");if(event.equals("ms.channel.connect")){connected=true;setStatus("Conectado! Teste os botões.");}else if(event.equals("ms.channel.unauthorized")){connected=false;setStatus("A TV recusou o acesso. Verifique as permissões.");}}catch(Exception ignored){}}
        @Override public void onFailure(WebSocket ws,Throwable e,okhttp3.Response response){if(attempt==connectionAttempt){connected=false;setStatus("Falha ao conectar: "+e.getMessage()+". Verifique IP e autorização da TV.");}}
        @Override public void onClosed(WebSocket ws,int code,String reason){if(attempt==connectionAttempt){connected=false;setStatus("Conexão encerrada.");}}
      });
    }catch(Exception e){setStatus("Erro: "+e.getMessage());}
  }
  private void send(String key){if(!connected||socket==null){setStatus("Conecte à TV antes de usar os botões.");return;}try{JSONObject d=new JSONObject();d.put("Cmd","Click");d.put("DataOfCmd",key);d.put("Option","false");d.put("TypeOfRemote","SendRemoteKey");JSONObject cmd=new JSONObject();cmd.put("method","ms.remote.control");cmd.put("params",d);if(!socket.send(cmd.toString()))setStatus("Não foi possível enviar o comando.");}catch(Exception e){setStatus("Erro ao enviar: "+e.getMessage());}}
  @Override protected void onDestroy(){connectionAttempt++;if(socket!=null)socket.close(1000,"bye");executor.shutdownNow();super.onDestroy();}
}
